import streamlit as st
import plotly.express as px
import pandas as pd



# Membaca data dari file CSV
data = pd.read_csv('https://raw.githubusercontent.com/Kajaxssss/projekdataa/main/main_data.csv')

# Mengatur judul dan deskripsi aplikasi
st.title('Pilih Untuk Menampilkan Dashboard')
st.markdown('Visualisasi data pengambilan data di Gucheng')

# Memilih kolom yang akan ditampilkan
columns = st.multiselect('Pilih kolom', data.columns)

# Menampilkan data yang telah dipilih
if columns:
    st.dataframe(data[columns])
    


# Line chart kualitas udara
fig = px.line(data, x='year', y='PM2.5'
              , color='station',
              title='kualitas udara', labels={'tahun': 'year', 'kualitas_pm': 'PM2.5', 'station': 'station'})
st.plotly_chart(fig)

fig = px.ecdf(data, x="CO", color="year")
st.plotly_chart(fig)

# Data iris
fig = px.density_contour(data, x="PM2.5", y="year")
st.plotly_chart(fig)

# bar chart kualitas Udara
fig = px.bar(data, x='year', y='CO')
st.plotly_chart(fig)


