Dashboard

Setup 
```
conda create --name main-ds 
conda activate main-ds
pip install numpy pandas scipy matplotlib seaborn jupyter streamlit babel
```

Run steamlit 
```
streamlit run dashboard.py
```

